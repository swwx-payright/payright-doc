//
//  ViewController.h
//  PayRightSDK
//
//  Created by zhulebei on 16/3/2.
//  Copyright © 2016年 shunweiwuxian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

